# PDF 文档生成

SDK 0.3.12 / Plugin API `^2.9.0` 新增可选 `ctx.documents`。插件须声明 `documents.render`；第三方插件需要用户授权，系统插件按已有规则授予声明权限。旧宿主没有该 API，兼容插件需检查存在性；使用新权限的清单应声明 `^2.9.0`。

```ts
const result = await ctx.documents!.renderPdf({
  html: '<!doctype html><meta charset="utf-8"><style>body{font-family:sans-serif}</style><h1>报告</h1>',
  pageSize: "A4",
  landscape: false,
}, signal);
await ctx.fs.writeFile(outputPath, result.data, "base64");
```

`renderPdf(options, signal?)` 接收 `html: string`、可选 `pageSize: "A4" | "Letter"`（默认 A4）、`landscape: boolean`（默认 false），返回 `{ data: string, size: number, mimeType: "application/pdf" }`。`data` 是 base64 编码的 PDF。保存另需 `fs.write`，渲染接口本身不读写用户路径。

HTML 必须自包含：支持内联 CSS、图片/字体的 data URL；不执行脚本，不加载网络、本地文件、iframe 或插件页面，不共享用户页面登录态。外部资源会被阻止；需要本地图片时先经 `fs.read` 读取并转成 data URL。该能力不负责 OCR、PDF 编辑或 Office 格式转换。

HTML 的 UTF-8 字节数最多 4 MiB，PDF 最多 20 MiB。全宿主最多并发两个、排队八个，90 秒截止时间含排队。取消会结束排队或销毁渲染窗口；停用插件、Renderer 销毁和宿主关闭会释放任务。输入无效、缺权限、超限、超时或取消会拒绝 Promise；失败后可以提交新的请求。取消不回滚调用方已开始的文件写入。
