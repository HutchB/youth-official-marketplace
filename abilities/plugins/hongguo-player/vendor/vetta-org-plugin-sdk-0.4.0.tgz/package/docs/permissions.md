# 权限

插件必须在 `plugin.json` 的 `permissions` 数组里声明它要用的宿主 API。宿主在插件管理页**单独授权**，并在运行时校验。

> 权限是能力声明、用户知情同意和宿主 API 门控规范，**不是安全沙箱**。插件与宿主共享 renderer realm；请只安装和启用可信插件。

## 声明 → 授权 → 校验

1. **声明**：`plugin.json` 列出权限。未声明的权限永远拿不到。
2. **授权**：用户在设置 → 插件页为该插件勾选授权（系统插件自动全量授予、不可撤，见 [system-plugins.md](./system-plugins.md)）。Agent 经 `install-from-path` 安装时，确认后可**按声明一次授予**（见 [getting-started.md](./getting-started.md#安装)）。
3. **校验**：调用受门控的 API 时运行时检查；**未授权**会按下表两种方式之一处理。

更新插件（包括 GitHub 能力市场）保留用户已授予且新版本仍声明的权限，不自动授予新增权限，也不恢复用户撤销的权限。
若旧版市场更新已清空授权，详情页会提示配置面板未显示，可点击「检查插件权限」，在权限页开启「显示详情配置面板」以及所需的其它权限；无需卸载插件或重新授权服务商账号。保存权限后宿主自动重新加载插件。
宿主无法从空授权记录推断用户原来的选择，因此不会自动全量补授。

```ts
// 运行时也可自查
ctx.permissions.has("fs.read");      // boolean
ctx.permissions.require("fs.read");  // 缺则抛 Plugin permission denied: fs.read
```

## 缺权限的两种行为

不同注册点对「声明了但未授权」的处理不同：

- **抛错（require）**：`registerInputAction`、`registerCardRenderer`、`registerToolCallSlot`、`registerTurnCard`、`registerShortcutScope`、`openActivityTab`、`setActivityTabVisible`、`setPromptAttachment`、`fileExplorer.*`、`useBottomPanel().openTerminal`、`agent.registerContinuationProvider`、`agent.registerSystemPromptProvider`、`conversation.*`、`fs.*`、`network.*`、`storage.*`、`media.*`、`ai.*`、`command.run`。缺权限直接抛 `Plugin permission denied: <permission>`，中断该次调用。
- **跳过 + 警告（warn+noop）**：`registerGlobalSlot`、`registerFilePreview`、`registerActivityTab`、`registerNewSessionContext`、`agent.registerTool`、`agent.registerHook`、`appActions.register`。缺权限时静默跳过该贡献并打 `console.warn`，**不影响**插件其它已授权能力。

> 设计上一个缺失权限不应拖垮插件的其它能力——`activate()` 里建议把可选能力的注册各自独立，避免一处 throw 掉整段。

## 已实现权限（有对应 API / 清单面）

| 权限 | 门控 | 文档 |
| --- | --- | --- |
| `ui.slot.global` | `ctx.ui.registerGlobalSlot()` | [ui-slots](./ui-slots.md#全局浮层-registerglobalslot) |
| `ui.slot.workspace-view` | `ctx.ui.registerWorkspaceView()` / `openWorkspaceView()` / `setWorkspaceViewBadge()` | [ui-slots](./ui-slots.md#工作区视图-registerworkspaceview) |
| `ui.slot.file-preview` | `ctx.ui.registerFilePreview()` | [ui-slots](./ui-slots.md#文件预览-registerfilepreview) |
| `ui.slot.activity-tab` | `registerActivityTab` / `openActivityTab` / `setActivityTabVisible` | [ui-slots](./ui-slots.md#活动面板-tab-registeractivitytab) |
| `ui.slot.bottom-panel` | `registerBottomPanel` | [ui-slots](./ui-slots.md#会话底部面板-registerbottompanel) |
| `terminal.run` | 底部面板里的 `useBottomPanel().openTerminal()`（开终端并替用户敲命令） | [ui-slots](./ui-slots.md#替用户开终端跑命令-openterminal) |
| `ui.slot.input-action` | `registerInputAction` / `setPromptAttachment` | [ui-slots](./ui-slots.md#输入栏动作-registerinputaction) |
| `ui.slot.new-session-context` | `ctx.ui.registerNewSessionContext()` | [ui-slots](./ui-slots.md#新会话上下文区-registernewsessioncontext) |
| `conversation.draft.read` | 新会话上下文区的 `context.draft`（未授予恒为空串） | 同上 |
| `ui.slot.message` | `ctx.ui.registerCardRenderer()` | [message-cards](./message-cards.md) |
| `ui.slot.tool-call` | `ctx.ui.registerToolCallSlot()` | [ui-slots](./ui-slots.md#工具行内渲染-registertoolcallslot) |
| `ui.slot.turn-card` | `ctx.ui.registerTurnCard()` | [ui-slots](./ui-slots.md#本轮-turn-卡-registerturncard) |
| `ui.slot.ability-detail` | `ctx.ui.registerAbilityDetailSlot()` | [下方](#尚无专章的能力) |
| `ui.shortcuts.register` | `ctx.ui.registerShortcutScope()` / `usePluginShortcutScope` | [ui-slots](./ui-slots.md#键盘快捷键-registershortcutscope) |
| `ui.file-explorer.decorations` | `ctx.fileExplorer.registerDecorationProvider()` | [file-explorer](./file-explorer.md#文件装饰) |
| `ui.file-explorer.context-menu` | `ctx.fileExplorer.registerContextMenuAction()` | [file-explorer](./file-explorer.md#右键菜单) |
| `ui.file-explorer.toolbar` | `ctx.fileExplorer.registerToolbarAction()` | [file-explorer](./file-explorer.md#工具栏动作) |
| `workspace.read` | 文件列表查询、定位、刷新与事件 | [file-explorer](./file-explorer.md#工作区选择与定位) |
| `agent.session.read` | `ctx.conversation.on()` + 对话 hook | [conversation-and-agent](./conversation-and-agent.md#对话读状态) |
| `agent.session.write` | `sendPrompt` / `insertText` / `abort` | [conversation-and-agent](./conversation-and-agent.md#对话驾驶) |
| `agent.command.run` | `ctx.command.run` + 清单 `commands` | [conversation-and-agent](./conversation-and-agent.md#命令执行-command) |
| `agent.command.spawn` | `ctx.command.spawn`（长驻进程）+ 清单 `commands` | [conversation-and-agent](./conversation-and-agent.md#长驻进程-commandspawn) |
| `capture.offscreen` | `ctx.capture.offscreen`（主进程离屏窗口截图） | [conversation-and-agent](./conversation-and-agent.md#离屏截图-captureoffscreen) |
| `documents.render` | `ctx.documents.renderPdf`（自包含 HTML 生成 PDF，API 2.9.0） | [documents](./documents.md) |
| `agent.skills.control` | 清单 `agent.skillPaths` | [manifest](./manifest.md#agent-agent-侧贡献) |
| `agent.mcp.control` | 清单 `agent.mcpServers`（三源聚合之插件源） | [mcp](./mcp.md) |
| `agent.tools.register` | `ctx.agent.registerTool()`（注册 shell） | [conversation-and-agent](./conversation-and-agent.md#注册-agent-工具) |
| `agent.toolHandler.execute` | 工具 handler 被 agent 调用时执行 | 同上 |
| `agent.hooks.register` | `ctx.agent.registerHook()`（注册 Coding Agent 生命周期 Hook） | [conversation-and-agent](./conversation-and-agent.md#注册-coding-agent-hook) |
| `agent.hookHandler.execute` | Coding Agent 到达匹配事件时调用插件 Hook handler | 同上 |
| `agent.tools.control` | 清单 `agent.toolPolicy`；动态 `setToolEnabled` / `actions.tools.*` | [manifest](./manifest.md#agent-agent-侧贡献) / [conversation-and-agent](./conversation-and-agent.md#注册动态系统提示词-provider) |
| `agent.systemPrompt.write` | `registerSystemPromptProvider`；仅本插件 block | [conversation-and-agent](./conversation-and-agent.md#注册动态系统提示词-provider) |
| `agent.systemPrompt.fullControl` | 动态 provider 操作非本插件 block | 同上 |
| `agent.continuation.register` | `registerContinuationProvider` | [conversation-and-agent](./conversation-and-agent.md#注册-agent-自动续跑策略) |
| `app.actions.register` | `ctx.appActions.register()`（注册声明） | [app-actions](./app-actions.md) |
| `app.actionHandler.execute` | Action handler 被本地 Action RPC 调用时执行 | 同上 |
| `fs.read` | `readDir` / `readFile` / `stat` / `listFilesRecursive` | [conversation-and-agent](./conversation-and-agent.md#文件-api) |
| `fs.write` | `writeFile` / `rename` / `delete` / `move` / `createDirectory` | 同上 |
| `network.fetch` | `ctx.network.request` | [conversation-and-agent](./conversation-and-agent.md#网络-api) |
| `browser.read` | 创建/查询/关闭 session，导航、快照、文本与截图 | [browser](./browser.md) |
| `browser.open` | `ctx.browser.open`；仅打开宿主内置 Browser Panel，不读取或操作页面 | [browser](./browser.md) |
| `browser.interact` | `ctx.browser.act`；必须同时声明 `browser.read` | [browser](./browser.md) |
| `browser.profile.persist` | 创建宿主管理的持久 profile | [browser](./browser.md#多账号-profile) |
| `browser.attach` | 附着用户自行开启调试的 Chrome | [browser](./browser.md) |
| `browser.runtime.manage` | 安装/修复浏览器运行时 | [browser](./browser.md) |
| `storage.read` | `ctx.storage.list/readFile/readSnapshot/readBlob/getBlobRef` | [conversation-and-agent](./conversation-and-agent.md#插件私有存储-api) |
| `storage.write` | `ctx.storage.writeFile/commit/putBlob/putBlobFromFile` | 同上 |
| `secrets.read` | `ctx.secrets.get/has/keys` | [conversation-and-agent](./conversation-and-agent.md#密钥-api) |
| `secrets.write` | `ctx.secrets.set/delete` | 同上 |
| `media.generate` | `ctx.media.listProviders/createJob/getJob/cancelJob` | [media](./media.md) |
| `media.provider.register` | `ctx.media.registerProvider`（注册媒体 Provider） | [media](./media.md#注册-provider) |
| `ai.models.list` | `ctx.ai.listModels()` | [ai](./ai.md) |
| `ai.complete` | `ctx.ai.complete()` / `ctx.ai.stream()` / `ctx.ai.chat()` | [ai](./ai.md) |
| `models.manage` | `ctx.models.replaceOwnedProviders()` / `listOwnedProviders()` | [下方](#尚无专章的能力) |
| `ai.ocr.recognize` | `ctx.ocr.recognize()` / `listProviders()` / `onProvidersChanged()` | [下方](#尚无专章的能力) |
| `ai.ocr.provider.register` | `ctx.ocr.registerProvider()`（注册 OCR Provider） | [下方](#尚无专章的能力) |
| `shell.openExternal` | `ctx.ui.openExternal()`（交给系统默认浏览器） | [下方](#尚无专章的能力) |
| `shell.openPath` | `ctx.ui.openPath()`（系统默认程序打开本地文件/目录） | [下方](#尚无专章的能力) |
| `system.processes.manage` | `ctx.processes`（按映像名查询/启动/结束本机进程） | [下方](#尚无专章的能力) |
| `fs.managed` | `ctx.fs.managed`（受管目录的 stat/列举/删除/大小，范围限 `plugin.json#fs.scopes`） | [下方](#尚无专章的能力) |
| `system.uiAutomation.manage` | `ctx.uiAutomation`（UIA 无障碍树：查询/点击/填值/读文本，Windows 专属） | [下方](#尚无专章的能力) |

> 清单 `agent.agents` / `agent.teams`（插件贡献的智能体与团队）**不需要权限**——那是声明面而非运行时 API，见 [manifest](./manifest.md#贡献智能体与团队)。
>
> `ctx.i18n` / **`ctx.ui.notify`** **不需要权限**——分别读本插件 catalog、以及向宿主右下角推送 Toast（含错误堆栈复制）。错误上报规范见 [ui-slots → notify](./ui-slots.md#全局通知-notify)。

## 尚无专章的能力

以下 API 已经实装并受权限门控，但还没有独立章节。这里给出用它们之前必须知道的边界；形状以
`@vetta-org/plugin-sdk` 的类型为准。

### ctx.ui.registerAbilityDetailSlot（`ui.slot.ability-detail`）

往**某个能力的详情页**里挂一块插件自绘的 UI，按 `abilityId` 定位目标能力。典型用途是承接上游
原生的配置流程（登录、装 CLI、填端点），而不是把这些塞进 `ability.json` 的静态区块。

- 缺权限 **warn+noop**；`abilityId` 必填，空串直接抛错。
- 与 [ability-details.md](./ability-details.md) 的分工：那是**声明式**的静态详情页（showcase、
  功能网格、Markdown），这里是**运行时**的交互区。

### ctx.models（`models.manage`）

维护**以本插件 id 命名**的模型 Provider，拿不到也改不了别人的。

- `replaceOwnedProviders(providers)` 是**原子快照**：省略即删除。所以每次写入都得重建完整真相。
- 正因如此，写之前先 `listOwnedProviders()` 读回宿主当前持有的状态并做对账——否则上游一时没返回的
  模型会被当成用户丢失的模型抹掉。读回的 `apiKey` 是掩码，下次写入要带上真凭据。
- SDK 0.3.7 的模型定义可声明 `reasoning: true`、`reasoningLevels`（上游原始档位字符串数组）和
  `defaultReasoningLevel`。例如 CPA 可发布 `["low", "medium", "high", "xhigh", "max"]`。
  档位省略或为空时回退到宿主的 API 类型预设；显式列表的默认值无效或省略时使用第一项，用户已选择的档位优先。
  需搭配保留这两个字段的 Desktop 模型写入合同；旧宿主可能静默清除它们，单独升级插件不能修复宿主。

- SDK 0.3.11（待发布）的模型定义可声明 `input: ["text", "image"]`；仅接受非空、不重复的 `text` / `image` 数组。省略时沿用宿主默认的文本输入。需要包含该写入合同修复的 Desktop（0.5.61 开发版）；旧宿主会清除该字段，单独升级插件不能启用图像输入。音频、视频、文件及原生搜索的上游声明不等同于宿主聊天输入或工具能力。

### ctx.ocr（`ai.ocr.recognize` / `ai.ocr.provider.register`）

两个方向，权限分开：**消费**识别能力用 `ai.ocr.recognize`（`recognize()` / `listProviders()` /
`onProvidersChanged()`），**提供**识别能力用 `ai.ocr.provider.register`（`registerProvider()`）。

- 消费方提交的是批量图片引用；取消走 `options.signal`。
- Provider 通过受控的输入 URL / 上传接口适配本地或远程服务，权限、取消、进度、能力协商与结果校验
  统一由宿主处理（ADR-0108）。

### ctx.ui.openExternal（`shell.openExternal`）

把 URL 交给**系统默认浏览器**，不是宿主内置的 Browser Panel（那是 `ctx.browser.open`，见
[browser.md](./browser.md)）。**只接受 `http:` / `https:`**，其它协议一律拒绝——这条限制是刻意的，
避免插件借它拉起任意 scheme（含 `file://`）。

### ctx.ui.openPath（`shell.openPath`）

用**系统默认程序**打开一个本地文件或目录（目录即资源管理器/Finder）。失败时抛错并带
Electron 的原因（如路径不存在）。要「在文件夹里定位某文件」请改用宿主文件面板的
reveal 语义；本权限只做「打开」。

### ctx.processes（`system.processes.manage`）【高权限】

“集成本机应用”类插件的通用原语组，全部走宿主统一审计通道，不需要插件自带脚本：

- `list(image)`：按映像名（含扩展名，如 `"player.exe"`）查运行中的进程；**不支持全量列举**——
  调用方必须知道自己在找什么。
- `launch(exePath, { args?, cwd? })`：启动本机程序，detached 语义（不随宿主/会话退出而
  终止），execFile 数组传参（无 shell 注入面）。
- `kill(image)`：按映像名结束**进程树**；幂等（目标不存在视为成功）。

### 声明式设置（`plugin.json#settings`，无需新权限）

`plugin.json#settings` 声明设置项，宿主在插件详情页（权限/命令开关下方）渲染通用设置
面板；值持久化在插件 storage 的 `settings.json`，与 `ctx.settings` / `ctx.storage` 同一
数据源（权限沿用 `storage.read` / `storage.write`）。插件零 UI 成本获得设置页。

```json
"settings": [
  { "key": "autoplay", "type": "switch", "label": "%setting.autoplay.label%", "default": true },
  { "key": "quality", "type": "select", "label": "清晰度", "default": "hd",
    "options": [ { "value": "sd", "label": "标清" }, { "value": "hd", "label": "高清" } ] },
  { "key": "speed", "type": "number", "label": "倍速", "default": 1.5, "min": 0.5, "max": 2 },
  { "key": "nickname", "type": "text", "label": "昵称" }
]
```

- `key`：`^[a-zA-Z][a-zA-Z0-9_.-]{0,63}$`，清单内唯一。
- `type`：`switch` / `text` / `number` / `select`（select 必带 `options`，`default` 须在选项内）。
- `label` / `description` / 选项 `label` 支持 `%catalogKey%`（按插件 catalog 解析）。
- 运行时读写（plugin API 2.11.0+）：`await ctx.settings.get()` 返回全部值（含 default
  回填）；`await ctx.settings.set(key, value)` 校验 key 已声明后整文件提交。

### ctx.uiAutomation（`system.uiAutomation.manage`）【高权限】

Windows UI Automation：按控件名称/AutomationId 精准操作任意暴露无障碍树的应用
（WebView2/Wails/Electron/Win32/WPF；自绘 UI 除外），用于自动化没有开放接口的
本机程序。plugin API 2.12.0+，旧宿主上为 `undefined`，使用前判空。

- `query({ processName, name?, automationId? })` → 控件数组（role/name/automationId/value/isEnabled/rect，限 200 节点、深 12 层）。
- `click({ … })` → `boolean`（Invoke/Toggle/ExpandCollapse/SelectionItem 自动择优；`false` 表示控件不支持这些 pattern，改用坐标兜底）。
- `setValue({ …, value })` → `boolean`（ValuePattern）。
- `readText(processName)` → 窗口全部可见文本（理解当前页面状态）。

目标进程按映像名定位（如 `"红果短剧.exe"`）；脚本经 PowerShell `.NET UIAutomationClient`
执行，输出单行 JSON。

## 占位符权限（已声明、暂无对应 API）

`PluginPermission` 联合里还包含以下值，目前是**声明了但还没对应能力 API** 的占位符，现在声明它们不会解锁任何功能：

`agent.systemPrompt.read`、`agent.state.read`、`agent.state.write`、`agent.runtime.configure`、`settings.read`、`settings.write`。

## 最小授权原则

只声明真正用到的权限。`permissions` 越小，用户授权越省心、审核越快。

使用 `@vetta-org/plugin-vite` 构建或执行 `vetta-plugin pack` 时，构建器会检查最终 JavaScript
产物和 `plugin.json` 的能力声明；发现 `registerSystemPromptProvider`、`setToolEnabled`、
`registerTool`、`registerHook` 等能力缺少对应权限时会直接终止构建。运行时权限校验仍然保留，
用于验证用户是否实际授权并约束通过宿主公开 API 发起的调用。
