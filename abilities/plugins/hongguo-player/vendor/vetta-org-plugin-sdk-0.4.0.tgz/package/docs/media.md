# 媒体 Provider 协议

`ctx.media` 负责媒体能力发现与提交；通用任务生命周期在 `ctx.jobs`，临时产物生命周期在 `ctx.artifacts`。消费者不依赖具体模型、供应商、网关或本地渲染引擎。

## 消费媒体能力

需要 `media.generate` 权限。按 `operation` 和具体能力选择 Provider：

```ts
const provider = (await ctx.media.listProviders()).find((item) =>
  item.capabilities.some(
    (capability) =>
      capability.operation === "generate" &&
      capability.kind === "image" &&
      capability.modes.includes("text-to-image"),
  ),
);

if (!provider) throw new Error("No image provider available");

const submitted = await ctx.media.submit({
  operation: "generate",
  providerId: provider.id,
  kind: "image",
  mode: "text-to-image",
  prompt: "a red fox in snow",
  modelId: "openai/gpt-image-2",
  dimensions: { width: 1024, height: 1024 },
  inputs: [],
});

const job = await ctx.jobs.wait(submitted);
```

`generate` 用于提示词驱动的图片或视频生成。`compose` 接收工程文档与素材，`transcode` 接收一个媒体输入和目标输出：

```ts
const submitted = await ctx.media.submit({
  operation: "compose",
  providerId: provider.id,
  inputs: [{
    kind: "document",
    mimeType: "application/vnd.example.timeline+json",
    source: { type: "plugin-blob", blobId: projectBlob.id },
  }],
  output: { kind: "video", mimeType: "video/mp4", fps: 30 },
});
```

工程 MIME 由 Provider 声明。Remotion、其他时间线引擎或模板渲染器都使用 `compose`，具体 composition、props 和 bundle 信息留在各自工程文档中。

任务状态为 `queued | running | succeeded | failed | cancelled`。`ctx.jobs.get()` 查询一次，`wait()` 轮询到终态，`cancel()` 请求取消。任务 ID 由宿主生成，不等于 Provider 的内部队列 ID。

输入素材通过句柄传递，不再嵌入 base64。插件私有素材使用 `plugin-blob`，工作区文件使用 `workspace-file`：

```ts
inputs: [
  { kind: "image", source: { type: "plugin-blob", blobId: image.id } },
  { kind: "audio", source: { type: "workspace-file", path: audioPath } },
]
```

成功结果的 `artifacts[]` 也是宿主管理的临时句柄，只包含 ID、MIME、大小和媒体元数据。插件必须明确选择保存位置，并在使用完成后释放临时产物：

```ts
const artifact = job.artifacts[0];
if (!artifact) throw new Error("Media provider returned no artifact");

try {
  const saved = await ctx.artifacts.persist(artifact, { type: "plugin-blob" });
  // saved.blobId / saved.url can be stored in plugin state.
} finally {
  await ctx.artifacts.release(artifact);
}
```

`plugin-blob` 读写分别要求 `storage.read` / `storage.write`，`workspace-file` 读写分别要求 `fs.read` / `fs.write`。字节始终由宿主在主进程内按需读取或复制，不经过插件渲染进程；`release()` 只释放临时产物，不删除已经保存的文件或 Blob。

消费插件可用 `onProvidersChanged()` 监听 Provider 增删，并重新执行能力发现。插件并行激活时不能依赖固定加载顺序。

官方系统插件如果需要遵循宿主 Agent 的图片 Provider 与模型选择，应使用 `ctx.official.agent.getImageGeneration()` 读取
`textToImageProviderId` / `textToImageModelId` 与 `imageToImageProviderId` / `imageToImageModelId`。只保存了 Provider 的旧配置
继续使用该 Provider 的 `defaultModelId`。已保存但当前不存在或不支持对应模式的 Provider/模型必须报告
`provider-unavailable`，不能静默切换到另一条路由。
Provider 的凭据、模型和服务端参数仍由 Provider 自己管理，不应复制到 Agent 设置。

## 注册 Provider

Provider 插件需要 `media.provider.register`。只有远程传输才需要 `network.fetch`；本地渲染输出可使用插件 Blob 或工作区文件。

```ts
ctx.media.registerProvider({
  id: "local-video",
  displayName: "Local video",
  capabilities: [{
    operation: "generate",
    kind: "video",
    modes: ["image-to-video"],
    aspectRatios: ["16:9", "9:16"],
    resolutions: ["efficient", "balanced", "quality"],
    defaultResolution: "balanced",
    models: [{
      id: "acme/video-v2",
      displayName: "Video v2",
      sourceId: "acme",
      sourceDisplayName: "Acme",
      modes: ["image-to-video"],
    }],
    defaultModelId: "acme/video-v2",
    durationsSeconds: [5, 10],
  }],
  async submit(request, context) {
    if (request.operation !== "generate") {
      return {
        id: crypto.randomUUID(),
        status: "failed",
        error: { code: "operation-unsupported", message: "Unsupported operation", retryable: false },
      };
    }
    const image = request.inputs.find((item) => item.kind === "image");
    if (!image) throw new Error("An image is required");
    await context.uploadInput(image.id, {
      url: "http://127.0.0.1:8188/upload/image",
      fieldName: "image",
    });
    // Adapt request.prompt / aspectRatio / durationSeconds inside the provider.
    return { id: "provider-job-id", status: "queued" };
  },
  async getJob(jobId) {
    return {
      id: jobId,
      status: "succeeded",
      artifacts: [{
        kind: "video",
        source: { type: "remote-url", url: "http://127.0.0.1:8188/view?..." },
      }],
    };
  },
});
```

Provider 收到的 `inputs` 只有不透明 ID、媒体类型和 MIME，不包含插件 Blob 命名空间或工作区路径。只有当前任务上下文能读取它们：`uploadInput()` 把文件流式上传到 HTTP(S) 服务；`readInput()` 返回 `{ mimeType, data }`，用于 Gemini `inlineData` 一类必须把字节放进 JSON 的 API。`readInput()` 上限 32 MB，调用结束、取消或 Provider 卸载后句柄立即失效，不能读取未列入本次请求的文件。Provider 输出 source 支持 `remote-url`、`plugin-blob` 和 `workspace-file`，宿主会按 Provider 权限读取并导入为消费方临时产物。

`models` 是可选的兼容字段：省略时按旧版 Provider 级能力工作。提供时，模型 `id` 在同一 capability 内必须唯一，模型的 `modes` 必须是 Provider `modes` 的子集，`defaultModelId` 必须引用目录中的模型。消费者没有传 `modelId` 时宿主使用 `defaultModelId`；显式模型缺失或不支持当前模式时返回 `invalid-request`，不会静默替换。模型可用 `sourceId` / `sourceDisplayName` 表达同一 Provider 后面的上游供应商分组。

`resolutions` 是 Provider 自定义的稳定选项 ID，不保证具有 `720p`、`2K` 等固定视频制式语义；例如本地模型可以用它表达像素预算档位，再在 Provider 内转换为最终宽高。若声明 `defaultResolution`，该值必须同时出现在 `resolutions` 中。消费者在没有已保存值或已有值不受当前模型支持时优先采用这个显式默认值。

## Provider SPI

通用媒体契约和 capability token 定义在 `@vetta-org/capability-sdk`，当前协议版本为 5。注册表、通用任务、临时产物存储、输入解析与网络传输位于 desktop 主进程。插件 Provider 通过受控 IPC 回调桥接到同一个 Registry，注销时会中止仍在执行的调用。使用模型目录或 `readInput()` 的插件应声明 `pluginApiVersion: ^2.4.0`；旧 Provider 不声明模型目录时继续按原行为运行。

需要宿主凭据或其它主进程特权的实现仍应注册为宿主 Provider；普通远端服务、本地模型或 sidecar 可用 Provider 插件适配。两者对消费者暴露同一契约。

## Desktop 内置 Vetta Provider

desktop 默认注册 `desktop:vetta`，当前支持 `text-to-image` 与 `image-to-image`。它的实现位于主进程：renderer 只提交媒体协议请求，主进程固定选择 `images/generate` 或 `images/edit`，并负责注入 JWT 与刷新凭据。插件拿不到用户 token，也不能通过该接口传入任意网关路径。

该内置实现不是底层协议的前提。没有它的宿主构建仍可暴露一个空 Registry；消费者必须处理 `listProviders()` 为空和 `provider-unavailable`。
